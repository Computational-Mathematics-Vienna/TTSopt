

A = [9 0 0 0 0 0;0 0 0 1 0 0; 0 2 4 5 4 8; 0 0 0 3 4 0; 8 0 0 3 4 8];
x = [1 2 3 4 5 6]';
b = A * x;

numEqCon = size(A,1);
numVariables = zeros(numEqCon,1);
dim = size(A,2);
% numEqCon = arrayfun(@nnz,A(1:,:)),
for k = 1:numEqCon
    numVariables(k) = nnz(A(k,:));
end

o = true;
while o 
    justOne = find(numVariables == 1);
    if isempty(justOne)
        o = false;
    else
        for k = justOne
            disp(k)
        end
        oneHit = x(justOne);
        VecOneHit = zeros(dim,1);
        VecOneHit(justOne) = oneHit;


        ObjConst = dot(S.prob.obj.lin,vecContHit);
        EqConConst = S.prob.con.lin.Aeq * vecContHit;
        IneqConConst = S.prob.con.lin.Aineq * vecContHit;     
    end

end