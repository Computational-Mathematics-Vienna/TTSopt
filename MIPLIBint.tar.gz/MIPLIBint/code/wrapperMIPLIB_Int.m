%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% wrapperMIPLIB_Int.m %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% written by Roman Kostal
12.10.2021

tic
base = 'C:\Users\roman\OneDrive\Work\DFO_Project\MIPLIB\';
pthCol = strcat(base,'collection\');
pthDotMat = strcat(base,'collection_DotMat\');
pthDM_Int = strcat(base,'integer_collection_DotMat\');

cd(base);
        
load('goodHitNames.mat');
info = cell(length(goodHitNames),6);
info(:,1) = goodHitNames;



cd(pthDotMat);
for j = 371:length(goodHitNames)
    try
    disp(strcat('processing____',num2str(j), '/',num2str(length(goodHitNames))));
    fs = goodHitNames{j};
    load(fs);
    contInd = find(S.prob.domain.xtype == 0);
    intInd = find(S.prob.domain.xtype ~= 0);
    
%     A = S.hits;
%     S.hits = cell(1,1);                % will be redundant, move this code to wrapperMIPLIB
%     S.hits{1}.names = A{1,1}(2:end);   % will be redundant, move this code to wrapperMIPLIB
%     S.hits{1}.values = A{1,2}(2:end);  % will be redundant, move this code to wrapperMIPLIB
%     S.hits{1}.obj = A{1,2}(1);         % will be redundant, move this code to wrapperMIPLIB
    
    contHit = S.hits{1,1}.values(contInd);
    vecContHit = zeros(length(S.prob.domain.xtype),1);
    vecContHit(contInd) = contHit;
    
    % find values
    ObjConst = dot(S.prob.obj.lin,vecContHit);
    EqConConst = S.prob.con{1,1}.lin * vecContHit;
    IneqConConst = S.prob.con{1,2}.lin * vecContHit;
    
    % adjust
    %S.prob.obj.const = -ObjConst; %???????????????????????????????????????
    S.hits{1}.obj = S.hits{1}.obj - ObjConst;
    % the RHS in the equality constraint
    S.prob.con{1,1}.lb = S.prob.con{1,1}.lb - EqConConst;
    S.prob.con{1,1}.ub = S.prob.con{1,1}.lb;
    % same for the RHS in the inequality constraint
    S.prob.con{1,2}.ub = S.prob.con{1,2}.ub - IneqConConst;
    
    
    % delete
    % in the obj function
    S.prob.obj.lin(contInd) = [];
    
    % columns in constraint matrices
    S.prob.con{1,1}.lin(:,contInd) = [];
    S.prob.con{1,2}.lin(:,contInd) = [];
    
    % in the xtype vector
    S.prob.domain.xtype(contInd) = [];
    S.prob.domain.lb(contInd) = [];
    S.prob.domain.ub(contInd) = [];
    
    % in hits
    S.hits{1}.names = {S.hits{1}.names{intInd}}';
    S.hits{1}.values = S.hits{1}.values(intInd);

    
    %count variables involved in a given equality constraint
    numEqCon = size(S.prob.con{1,1}.lin,1);
    %numVariables = zeros(numEqCon,1);
    numVariables = arrayfun(@(r) nnz(S.prob.con{1,1}.lin(r,:)), (1:numEqCon).');
%     for k = 1:numEqCon
%         numVariables(k) = nnz(S.prob.con{1,1}.lin(k,:));    
%     end
    rowsWithOneVar = find(numVariables == 1);
    
    o = true;
    countElim = 0;
    D = [];
    while o 
        if isempty(rowsWithOneVar)
            o = false;
        else
            row = rowsWithOneVar(1);
            col = find(S.prob.con{1,1}.lin(row,:));
            computedHit = (S.prob.con{1,1}.lb(row))/(S.prob.con{1,1}.lin(row,col));
            if (~isempty(S.hits{1,1}.values))
                givenHit = S.hits{1,1}.values(col);
                oneHit = givenHit;
                difference = abs(computedHit - givenHit);
            else 
                givenHit = NaN;
                oneHit = computedHit;
                difference = NaN;
            end
            vecOneHit = zeros(length(S.prob.domain.xtype),1);
            vecOneHit(col) = oneHit;
            
            % adjust
            S.prob.obj.const = S.prob.obj.const - dot(S.prob.obj.lin,vecOneHit);
            S.hits{1}.obj = S.hits{1}.obj - dot(S.prob.obj.lin,vecOneHit);
            S.prob.con{1,1}.lb = S.prob.con{1,1}.lb - S.prob.con{1,1}.lin * vecOneHit;
            S.prob.con{1,1}.ub = S.prob.con{1,1}.lb;
            S.prob.con{1,2}.ub = S.prob.con{1,2}.ub - S.prob.con{1,2}.lin * vecOneHit;
            
            % delete
            % in the objective function
            S.prob.obj.lin(col) = [];
            
            % rows/cols in constraint matrices
            S.prob.con{1,1}.lin(row,:) = [];
            S.prob.con{1,1}.lin(:,col) = [];
            S.prob.con{1,2}.lin(:,col) = [];

            % in xtype vector
            S.prob.domain.xtype(col) = [];
            S.prob.domain.lb(col) = [];
            S.prob.domain.ub(col) = [];
            
            % in hits
            S.hits{1}.names(col) = [];
            S.hits{1}.values(col) = [];
            countElim = countElim + 1;
            D(countElim) = difference;
            
            numVariables(row) = [];
            involvedRows = find(S.prob.con{1,1}.lin(:,col));
            numVariables(involvedRows) = numVariables(involvedRows) - 1;
            rowsWithOneVar = find(numVariables == 1);
        end
    end
        info{j,2} = length(contInd);
        info{j,3} = countElim;
        info{j,4} = abs(S.hits{1}.obj-dot(S.prob.obj.lin,S.hits{1}.values));
        info{j,5} = D;
        save(fullfile(pthDM_Int,strcat('integer_',fs,'.mat')),'S');
    catch e
        fprintf(1,'The identifier was:\n%s',e.identifier);
        fprintf(1,'There was an error! The message was:\n%s',e.message);
        fprintf(1,'------------\n');
        info{j,6} = e;
    end
    
        
end
    
    

%     
%     m = size(S.prob.con.lin.Aeq,1);
%     n = size(S.prob.con.lin.Aeq,2);
%     % Expand out to symmetric (M+N)x(M+N) matrix
%     B = [zeros(m,m), S.prob.con.lin.Aeq;
%              S.prob.con.lin.Aeq', zeros(n,n)];     
%     g = graph(B);
%     % Plot
%     h = plot(g);
%     bins = conncomp(g);
%     % Make it pretty
%     h.XData(1:m) = 1;
%     h.XData((m+1):end) = 2;
%     h.YData(1:m) = linspace(0,1,m);
%     h.YData((m+1):end) = linspace(0,1,n);
toc